import data_bratislava from "./Bratislava";
import data_trnava from "./Trnava";
import data_spiskanovaves from "./SpiskaNovaVes";

const locations = [
  ["Bratislava", data_bratislava],
  ["Trnava", data_trnava],
  ["Spiska Nova Ves", data_spiskanovaves],
];

export default locations;
