const xData1 = [1, 2, 3, 4, 5, 6];
const yData1 = [3, 7, 2, 9, 5, 10];

export { xData1, yData1 };
