import { Component } from "react";
import "./drop-down.css";
import locations from "../../data/locations";

class DropDown extends Component {
  state = {
    place: "",
    active: false,
  };

  componentDidMount = () => {
    const dd = document.querySelector(".drop-down_list");
    const btn = document.querySelector(".drop-down_btn");
    window.addEventListener("click", (e) => {
      if (
        !dd.contains(e.target) &&
        dd !== e.target &&
        btn !== e.target &&
        this.state.active
      )
        this.btnClose();
    });
  };
  /*   componentDidUpdate = () => {
    window.addEventListener("click", (e) => {
      e.preventDefault();
      if (this.state.active) this.onBtnClose();
    });
  }; */
  onBtnClick = () => {
    this.setState({
      active: !this.state.active,
    });
  };

  btnClose = () => {
    this.setState({
      active: false,
    });
  };

  onLocationChose = (location) => {
    this.props.onLocationChose(location);
    this.setState({
      active: !this.state.active,
      place: location,
    });
  };

  render() {
    const { place, active } = this.state;
    console.log("Drop down render");

    return (
      <div className="drop-down">
        <button
          className={active ? "drop-down_btn active" : "drop-down_btn"}
          onClick={(e) => {
            if (e.target === e.currentTarget) this.onBtnClick();
          }}
        >
          {place ? place : "Select Region"}
        </button>
        <ul className={active ? "drop-down_list active" : "drop-down_list"}>
          {locations.map((location) => (
            <li
              className={
                location[0] == place
                  ? "drop-down__item active"
                  : "drop-down__item"
              }
              key={location[0]}
              onClick={
                location[0] == place
                  ? null
                  : () => this.onLocationChose(location[0])
              }
            >
              {location[0]}
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

export default DropDown;
