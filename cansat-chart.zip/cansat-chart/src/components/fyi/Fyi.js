import { Component } from "react";
import "./fyi.css";

class Fyi extends Component {
  state = {
    triggered: false,
  };
  onFyiTrigger = () => {
    this.setState({
      triggered: !this.state.triggered,
    });
  };

  onHoverClose = () => {};

  render() {
    const { triggered } = this.state;
    const { location } = this.props;
    console.log(triggered);

    return (
      <>
        <div
          className={triggered ? "fyi__hover active" : "fyi__hover"}
          onClick={this.onFyiTrigger}
        >
          <div className="fyi__wrap">
            <p className="fyi__desc to-close">click anywhere to close</p>
          </div>
        </div>
        <div
          className={location ? "fyi active" : "fyi"}
          onClick={this.onFyiTrigger}
        >
          <p>?</p>
        </div>
      </>
    );
  }
}

export default Fyi;
