import { Component } from "react";
import ChartLine from "../chart-line/ChartLine";
import { xData1, yData1 } from "../../data/BA";
import "./chart-group.css";
import locations from "../../data/locations";
import logo from "../../img/logo.png";

const toShow = [
  "temperature",
  "pressure",
  "CO2",
  "CO",
  "CH4",
  "N2O",
  "S2O",
  "CH0",
  "N20",
  "S20",
  "TVOC",
  "speed",
  "altitude",
];

const colors = ["red", "orange", "yellow", "lime", "cyan", "magenta"];
let colorCh = 0;

const startupXYs = [];
for (let i = 0; i <= 25; i++) {
  startupXYs.push(i);
}

function generateRandomXY() {
  let xs = startupXYs.slice();
  let ys = [];
  colorCh !== 5 ? colorCh++ : (colorCh = 0);
  for (let i = 0; i <= startupXYs.length - 1; i++) {
    let num = Math.floor(Math.random() * 10) + 1;
    ys.push(num);
  }
  return [xs, ys, colorCh]; //x data, y data, color index
}

class ChartsGroup extends Component {
  componentDidMount = () => {
    this.intervalId = setInterval(this.displayRandom, 1500);
    //console.log("constructor");
    /* this.getTimeXs(0);
    this.getSubstanceYs("CO2", 0); */
  };

  state = {
    randomY: generateRandomXY()[1],
    staticX: startupXYs,
    color: "red",
  };

  getTimeXs = (placeIndex) => {
    const timeXs = [];
    const data = locations[placeIndex][1]; //placeN - index miesta, [1] - data of the miesto (check locations.js)
    let timeEnd = data[data.length - 1].time; //time at the end
    const timeArrEnd = timeEnd
      .slice(timeEnd.indexOf("T") + 1, timeEnd.indexOf("."))
      .split(":");
    for (let timeIndex = data.length - 1; timeIndex >= 0; timeIndex--) {
      let timeStart = data[timeIndex].time; // time at the start of timeN
      const timeArrStart = timeStart
        .slice(timeStart.indexOf("T") + 1, timeStart.indexOf(".")) // in string: "xx:xx:xx", then split in ['xx', 'xx', 'xx']
        .split(":");
      // console.log(`time start: ${+timeArrStart[2] - +timeArrEnd[2]}`);

      const timeX =
        +timeArrEnd[0] * 3600 +
        +timeArrEnd[1] * 60 +
        +timeArrEnd[2] -
        (+timeArrStart[0] * 3600 + +timeArrStart[1] * 60 + +timeArrStart[2]);
      timeXs.push(timeX);
    }
    return timeXs;
  };

  getSubstanceYs = (substance, placeIndex) => {
    const substanceYs = [];
    for (let measure of locations[placeIndex][1]) {
      substanceYs.push(measure[substance]);
    }
    return substanceYs;
  };

  getLocationXYs = (placeIndex) => {
    //main
    const data = [];
    const x = this.getTimeXs(placeIndex);
    let ch = 0;
    for (let substance of toShow) {
      let color = "blue";
      if (ch === 1 || ch === 4 || ch === 5 || ch === 8 || ch === 9 || ch === 12)
        color = "cyan";
      const pair = [
        substance,
        x,
        this.getSubstanceYs(substance, placeIndex),
        color,
      ]; // [C02, [1, 2, 3, 4, 5,....], [56, 654, 64234, 634,]]
      data.push(pair);
      ch++;
    }
    return data;
  };

  displayRandom = () => {
    const [xs, ys, colorIndex] = generateRandomXY();
    if (!this.props.location) {
      //console.log(colors[colorIndex]);
      this.setState({
        randomY: ys,
        staticX: xs,
        color: colors[colorIndex],
      });
    } else {
      //console.log("actived btn");
      clearInterval(this.intervalId);
    }
  };

  render() {
    //console.log(data[key]);
    const { location } = this.props;
    const { randomY, staticX, color } = this.state;
    let data = [];
    let locationIndex = 0;
    if (location) {
      for (locationIndex; locationIndex < locations.length; locationIndex++) {
        if (locations[locationIndex].includes(location)) break;
      }
      data = this.getLocationXYs(locationIndex);
      //console.log(data);
    }

    //console.log(locationIndex);
    return (
      <div className="container">
        <div className="desc">
          <h3 className="title">CANSAT Data Dashboard</h3>
          <p id="scroll">Interactive Visualization of Regional Measurements</p>
        </div>
        <div className="chart-group">
          {!location ? (
            <div className="chart-wrapper">
              <ChartLine
                xData={staticX}
                yData={randomY}
                colorStart={color}
                colorEnd={color}
                label={"Please Select Region To Start"}
                area={false}
              />
            </div>
          ) : (
            data.map((chart) => (
              <div className="chart-wrapper">
                <ChartLine
                  key={chart[0]}
                  xData={chart[1]}
                  yData={chart[2]}
                  colorStart={"#00000000"}
                  colorEnd={chart[3]}
                  label={chart[0]}
                  area={true}
                />
              </div>
            ))
          )}
        </div>
      </div>
    );
  }
}

export default ChartsGroup;

/* 

state: bratislava

[
    ["Bratislava", "BA"],
    [],
    []
]

{
    bratislava: {
        x: [],
        y; []
    }
}
*/
