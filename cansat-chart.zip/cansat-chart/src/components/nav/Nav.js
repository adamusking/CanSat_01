import DropDown from "../drop-down/DropDown";
import logoNav from "../../img/logoNav.png";
import "./nav.css";
import { render } from "@testing-library/react";
import { Component } from "react";

class Nav extends Component {
  render() {
    return (
      <nav className="nav">
        <div className="container">
          <div className="nav-wrapper">
            <a
              href="https://adlerkaspaceagency.eu/index.html"
              className="nav__logo"
            >
              <img src={logoNav} className="nav__logo-img" alt="logo" />
            </a>

            <DropDown onLocationChose={this.props.onLocationChose} />
          </div>
        </div>
      </nav>
    );
  }
}

export default Nav;
