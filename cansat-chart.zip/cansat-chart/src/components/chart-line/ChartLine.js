import { LineChart, markElementClasses } from "@mui/x-charts/LineChart";
import React from "react";
import "./chart-line.css";
import { Component } from "react";
import { colors } from "@mui/material";
import { useAnimate } from "@mui/x-charts";

class ChartLine extends Component {
  render() {
    const { xData, yData, colorStart, colorEnd, label, area } = this.props;
    return (
      <LineChart
        slotProps={{
          noDataOverlay: { message: "Please select region to display data" },
        }}
        xAxis={[{ data: xData }]} // x
        sx={{
          "& .MuiChartsAxis-left .MuiChartsAxis-tickLabel": {
            strokeWidth: 0.4,
            fill: "#ffffff",
          },
          // change bottom label styles
          "& .MuiChartsAxis-bottom .MuiChartsAxis-tickLabel": {
            strokeWidth: 0.4,
            fill: "#ffffff",
          },
          // x axis
          "& .MuiChartsAxis-bottom .MuiChartsAxis-line": {
            stroke: "#ffffff",
            strokeWidth: 1,
          },
          // y axis
          "& .MuiChartsAxis-left .MuiChartsAxis-line": {
            stroke: "#ffffff",
            strokeWidth: 1,
          },
          // upper label
          "& .MuiChartsLabel-root": {
            color: "#ffffff",
          },

          // punktir
          "& .MuiChartsAxisHighlight-root": {
            stroke: "#ffffff",
            strokeWidth: 1.5,
          },
          "& .MuiChartsAxis-tick": {
            stroke: "#4d4d4d",
          },
          "& .MuiChartsAxis-tick": {
            stroke: "#393838",
          },
          // grid
          "& .MuiChartsGrid-line": {
            stroke: "#393838",
          },
          // mal palochki
        }}
        series={[
          {
            label: label,
            area: area,
            color: colorEnd,
            data: yData, // y
            showMark: false,
          },
        ]}
        yAxis={[
          {
            hideTooltip: true,
            width: 30,
            colorMap: {
              type: "continuous",
              min: 0,
              max: Math.max(...yData),
              color: [colorStart, colorEnd],
            },
          },
        ]}
        height={350}
        grid={{ vertical: true, horizontal: true }}
        slots={!area ? { tooltip: () => null } : ""}
      />
    );
  }
}

export default ChartLine;
