import { Component } from "react";
import ChartsGroup from "./components/charts-group/ChartsGroup";
import Nav from "./components/nav/Nav";
import Fyi from "./components/fyi/Fyi";

class App extends Component {
  state = {
    location: "",
  };

  onLocationChose = (location) => {
    console.log(location);

    this.setState({
      location: location,
    });
  };

  render() {
    console.log("App render");
    const { location } = this.state;
    return (
      <div className="App">
        <Nav onLocationChose={this.onLocationChose} />
        <ChartsGroup location={location} />
        <Fyi location={location} />
      </div>
    );
  }
}

export default App;
